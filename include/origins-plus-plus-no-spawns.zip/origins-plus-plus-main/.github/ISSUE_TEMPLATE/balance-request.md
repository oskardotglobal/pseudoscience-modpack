---
name: Balance Request
about: Use this template to request a balance to an origin/power
labels: 'balance'
assignees: QuantumXenon

---
**Origin**
Which origin needs the balance?

**Power(s)**
Which power(s) need(s) to be balanced?

**Balance Suggestion**
Do you have any ideas about how it could be balanced?